## useful function, raises an error if the FLAG expression is FALSE
assert <- function( FLAG )
    .Defunct(new="stopifnot", package="gtools")

